using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("Unity.2D.PixelPerfect.Tests")]
[assembly: InternalsVisibleTo("Unity.2D.PixelPerfect.Editor")]
