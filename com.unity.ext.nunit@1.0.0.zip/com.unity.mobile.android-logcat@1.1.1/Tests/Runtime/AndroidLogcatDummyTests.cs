using System;
using NUnit.Framework;

class AndroidLogcatDummyTests
{
    [Test]
    public void DummyTest()
    {
        Console.WriteLine("This is a placeholder test, to make Katana happy. To run real Android Logcat tests, you need to switch active platform to Android in Editor");
    }
}