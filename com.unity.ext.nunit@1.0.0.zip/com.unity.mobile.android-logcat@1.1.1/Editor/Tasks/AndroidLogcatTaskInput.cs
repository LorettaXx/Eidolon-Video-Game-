#if PLATFORM_ANDROID

namespace Unity.Android.Logcat
{
    internal interface IAndroidLogcatTaskInput
    {
    }
}
#endif
